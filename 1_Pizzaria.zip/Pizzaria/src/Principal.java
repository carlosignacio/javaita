
public class Principal {

	public static void main(String[] args) {
		
		Pizza peperone= new Pizza();
		peperone.qtdIngredientes = 2;
		
		Pizza portuguesa= new Pizza();
		portuguesa.qtdIngredientes = 3;
		
		Pizza calabreza= new Pizza();
		calabreza.qtdIngredientes = 6;

		System.out.println(Pizza.qtdIngredientes +" Reais");

	}

}
