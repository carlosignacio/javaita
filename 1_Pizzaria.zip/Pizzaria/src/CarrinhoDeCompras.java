
public class CarrinhoDeCompras {
	int compras = 0; 
	public  void compra(Pizza qtdIngredientes){
		int compras = 0;
		qtdIngredientes.getPreco();
		compras = qtdIngredientes.qtdIngredientes; 
		}
		

}
