
public class contabilizaIngrediente {

}
