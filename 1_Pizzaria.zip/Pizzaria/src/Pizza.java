
public class Pizza {
	
	static int qtdIngredientes = 0;
		
	public int getPreco(){
		int total = 0;
		if (qtdIngredientes <= 2){
			total = 15;
			return total;
		} else if (qtdIngredientes >= 3 && qtdIngredientes <=5 ){
			total = 20;
			return total;
		} else {
			total = 23;
			return total;
		}
			 
	}
	
	public void contabilizaIngrediente (CarrinhoDeCompras cc) {
		qtdIngredientes = cc.compras; 
		}
}
	

